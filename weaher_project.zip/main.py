import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from weather_scraper.scraper import fetch_weather_data
url = 'https://ua.sinoptik.ua/%D0%BF%D0%BE%D0%B3%D0%BE%D0%B4%D0%B0-%D0%BB%D1%83%D1%86%D1%8C%D0%BA'

weather_data = fetch_weather_data(url)
print(weather_data)
