from bs4 import BeautifulSoup as bs

def parse_weather_data(html_content):
    """Функція для парсингу даних погоди з HTML-контенту"""
    soup = bs(html_content, 'html.parser')
    return soup.find_all('p', class_='today-temp')

def print_weather_forecast(items):
    """Функція для виведення прогнозу погоди"""
    for item in items:
        print(item.text)
