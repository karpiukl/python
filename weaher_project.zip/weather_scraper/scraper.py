import requests
from bs4 import BeautifulSoup as bs

def fetch_weather_data(url):
    response = requests.get(url)
    soup = bs(response.text, 'html.parser')
    p = soup.find_all('p', class_='today-temp')
    return [item.text for item in p]
